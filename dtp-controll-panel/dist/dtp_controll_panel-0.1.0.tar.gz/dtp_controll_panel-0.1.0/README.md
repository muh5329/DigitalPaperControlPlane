# DigitalPaperControlPlane

Sony Digital Paper control plane to show random stuff on a set interval


## Features

- Random daily art
- NYT or other newspaper [TODO] 
- Comic / Manga Page [TODO] 
- QR Code [TODO] 
- Word of the day[TODO] 
- Multi Function  [TODO]  
    - Weather
    - Calendar
    - Stocks


## Appendix

Makes use of https://github.com/janten/dpt-rp1-py python libraries to send commands to the e-paper device

## Install

Install with 
```
poetry install
```

Test with 
```
dtp-controll-panel
```
